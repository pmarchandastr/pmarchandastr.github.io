
       <li>
         <a href="">
         A chemical solver to compute molecule and grain abundances and non-ideal MHD resistivities in prestellar core collapse calculations
         </a>, 
         <span class="names">
         Marchand P., Masson J., Hennebelle P., Chabrier G., Commerçon B., Vaytet N.
         </span>,
         <span class="annee">
         2015
         </span>
         <span class="journal"> 
         A&A, number, page.
         </span> 
         <a href="" onclick="javascript:visibilite('d1'); return false;">More</a> </br>
        <span class="description" id="d1" style="display:none;">
        We have developed a code solving a chemical network to get equilibrium abundancesat various densities, temperature and cosmic rays ionisation rate. The network includes the ionised species H+, H2+, H3+, C+, K+, molecular ions such as H3O+, metallic ions (Mg+, Na+, Fe+...), and charged and neutral grains. Thermal ionisation of potassium and grain thermal evaporation are taken into account. Our work is mainly based on Umebayashi & Nakano (1990) and Kunz & Mouschovias (2009). We have computed an abundance table for typical densities, temperatures and CR ionisation rates of collapsing prestellar cores.
        </span> 
        </li>
