<!DOCTYPE html>


<html>
  
  <?php include('entete.php');?>
  
  <body>
  

    <?php include('menu.php');?>
 

     <div class="corpse">

     <h1>Curriculum Vitae</h1>

     
      <p><img src="NGC3628.jpg" alt="Pierre Marchand" id="pic_cv" /></p>

      <h2> Research life </h2>
      <dl> 
        <dt>Since Oct. 2014 :</dt><dd> PhD student at Centre de Recherche Astrophysique de Lyon (CRAL) with Gilles Chabrier and Benoît Commerçon. Numerical simulations of star formations (first and second Larson core).</dd>
      </dl>

 

      <h2>Teaching</h2>
      <dl>
        <dt>Since Feb. 2015 :</dt><dd> Teaching assistant in elemental mathematics for first year physics students. </dd>
        <dt>Since Feb. 2015 :</dt><dd> Teaching assistant in linear algebra for second year computer science students.</dd>
      </dl>

 
      <h2>Education</h2>
      <dl>  
        <dt>2013-2014 :</dt><dd> Master 2 in Astronomy and Astrophysics at Observatoire de Paris</dd>
        <dt>2010-2013 :</dt><dd> Engineer's degree in Energy at Ecole Centrale de Lyon.</dd>
        <dt>2008-2010 :</dt><dd> CPGE, MPSI/MP* at Chaptal, Paris. Two years of intensive mathematics and physics to prepare competitive examinations.</dd>
      </dl>

     </div> <!-- corpse -->

  </body>
   

</html>
