<!DOCTYPE html>


<html>
  
  <?php include('entete.php');?>
  
  <body>
  


  <?php include('menu.php');?>


     <div class="corpse">

     <h1>About me</h1>




       <p>
         <img src="Photo.jpg" alt="Pierre Marchand" class="Picture" />
         Welcome to my personal page. I am a PhD student at the Centre de Recherche Astrophysique de Lyon (CRAL), in France, since October 2014. I mainly work on numerical simulations of star formation with Gilles Chabrier and Benoit Commerçon.
         </p>
         <p>
         Please visit the "Research" page to learn more about my work.</p>
         <p>        
         The mailbox of my laboratory is : <br/>
         CRAL, ENS Lyon<br/>
         46 allée d'Italie <br/>
         69364 LYON Cedex 07.<br/>
<br/>
         You can also contact me at <a href= "mailto:pierre.marchand@ens-lyon.fr" class="mail"> pierre.marchand@ens-lyon.fr</a>.
       </p>

     </div> <!-- corpse -->

  </body>
   

</html>
