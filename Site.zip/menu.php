 


   <nav>
      <ul>
        <li><a href="index.php"> Homepage</a></li>
        <li><a href="CV.php"> CV </a></li>
        <li><a href="research.php"> Research </a></li>
        <li><a href="mailto:pierre.marchand@ens-lyon.fr"> Contact </a></li>
      </ul>
    </nav>



 <header>
    <div class='banniere'>
    <figure>
     <a href='index.php'> <img src="banner.jpg" alt="Webpage"/> </a>
    </figure>
    </div>
 </header>
