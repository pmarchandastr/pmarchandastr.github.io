 <head>
    <meta charset="utf-8" />
    <!--[if lt IE 9]>
    <script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="style.css" />
    <!--[if lte IE 7]>
    <link rel="stylesheet" href="style_ie.css" />
    <![endif]-->
    <title>Pierre Marchand</title>
  </head>
